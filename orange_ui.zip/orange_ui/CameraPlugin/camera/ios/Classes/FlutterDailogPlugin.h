#import <Flutter/Flutter.h>

@interface FlutterDailogPlugin : NSObject<FlutterPlugin>
@end

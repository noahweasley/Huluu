package com.retrytech.bubbly_camera

import android.annotation.SuppressLint
import android.app.Application

class MyApp : Application() {
    @SuppressLint("RestrictedApi")
    override fun onCreate() {
        super.onCreate()
    }
}